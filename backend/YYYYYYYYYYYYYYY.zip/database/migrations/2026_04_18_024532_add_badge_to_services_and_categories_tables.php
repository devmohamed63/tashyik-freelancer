<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('services', function (Blueprint $table) {
            $table->string('badge')->nullable()->after('warranty_days');
        });

        Schema::table('categories', function (Blueprint $table) {
            $table->string('badge')->nullable()->after('slug');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('services', function (Blueprint $table) {
            $table->dropColumn('badge');
        });

        Schema::table('categories', function (Blueprint $table) {
            $table->dropColumn('badge');
        });
    }
};
