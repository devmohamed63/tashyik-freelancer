<div>
    <button wire:click="renew({{ $user }})" class="py-0.5 px-2 flex items-center justify-center text-xs text-indigo-600 dark:text-indigo-500 bg-indigo-50 dark:bg-indigo-500/15 hover:bg-indigo-100 dark:hover:bg-indigo-800/50 gap-1 rounded-full font-medium transition" type="button">
        {{ __('ui.renew') }}
        <!-- material-symbols-light:star-shine -->
        <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24"><!-- Icon from Material Symbols Light by Google - https://github.com/google/material-design-icons/blob/master/LICENSE -->
            <path fill="currentColor" d="M20.896 18.008L18.608 15.7l.688-.688l2.308 2.288zM17.7 6.373l-.688-.688L19.3 3.396l.708.689zm-11.4.02L4.011 4.084l.689-.689l2.308 2.289zM3.085 18.007l-.689-.708l2.289-2.289l.707.689zM6.44 20l1.47-6.275L3 9.481l6.47-.548L12 3l2.55 5.933l6.47.548l-4.912 4.244L17.578 20L12 16.66z" />
        </svg>
    </button>
</div>
